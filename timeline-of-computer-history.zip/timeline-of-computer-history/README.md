# Timeline of Computer History

A Pen created on CodePen.io. Original URL: [https://codepen.io/mistyconaway/pen/wvjPbpX](https://codepen.io/mistyconaway/pen/wvjPbpX).

